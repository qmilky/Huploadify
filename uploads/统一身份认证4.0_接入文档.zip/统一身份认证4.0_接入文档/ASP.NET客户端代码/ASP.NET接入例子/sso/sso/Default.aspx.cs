﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetCasClient;


namespace sso
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 获取退出信息地址
            String logout = System.Configuration.ConfigurationManager.AppSettings["caslogoutUrl"] + "?service=" + System.Configuration.ConfigurationManager.AppSettings["serverName"];
            // 设置退出单点登录注销地址
            LoginStatus1.LogoutPageUrl = logout;
        }
    }
}